TwitchEmotes_Baddies_Emoticons = {
    ["Crungo"] = "Crungo",
    ["sputSussy"] = "sputSussy",
    ["OhSnap"] = "OhSnap",
    ["mhm"] = "mhm",
    ["GLORPSHIT"] = "GLORPSHIT",
    ["Shoo"] = "Shoo",
    ["NOOOO"] = "NOOOO",
    ["yippee"] = "yippee",
    ["clappi"] = "clappi",
    ["Shrug"] = "Shrug",
    ["splort"] = "splort",
    ["ReallyMad"] = "ReallyMad",
    ["DOESHEKNOW"] = "DOESHEKNOW",
    ["CAUGHT"] = "CAUGHT",
    ["DEAL"] = "DEAL",
    ["doid"] = "doid",
    ["SadCatClown"] = "SadCatClown",
    ["FRICK"] = "FRICK",
    ["CEASE"] = "CEASE",
    ["sputWide"] = "sputWide",
    ["lookUp"] = "lookUp",
    ["lookDown"] = "lookDown",
    ["CRIKEN"] = "CRIKEN",
    ["SoyR"] = "SoyR",
    ["WHOLETHIMCOOK"] = "WHOLETHIMCOOK",
    ["THESTAFF"] = "THESTAFF",
    ["devious"] = "devious",
    ["RightThere"] = "RightThere",
    ["LetMeIn"] = "LetMeIn",
    ["CatAHomie"] = "CatAHomie",
    ["LockedIn"] = "LockedIn",
    ["AAAA"] = "AAAA",
    ["petbabey"] = "petbabey",
    ["babey"] = "babey",
    [""] = "",
    [""] = "",
    [""] = "",

}

TwitchEmotes_Baddies_Emoticons_Pack = {
    ["Crungo"] = "Interface\\AddOns\\TwitchEmotes_Baddies\\emotes\\Crungo.tga:28:28",
    ["sputSussy"] = "Interface\\AddOns\\TwitchEmotes_Baddies\\emotes\\sputSussy.tga:32:32",
    ["OhSnap"] = "Interface\\AddOns\\TwitchEmotes_Baddies\\emotes\\OhSnap.tga:32:32",
    ["mhm"] = "Interface\\AddOns\\TwitchEmotes_Baddies\\emotes\\mhm.tga:32:32",
    ["GLORPSHIT"] = "Interface\\AddOns\\TwitchEmotes_Baddies\\emotes\\GLORPSHIT.tga:32:32",
    ["Shoo"] = "Interface\\AddOns\\TwitchEmotes_Baddies\\emotes\\Shoo.tga:32:32",
    ["NOOOO"] = "Interface\\AddOns\\TwitchEmotes_Baddies\\emotes\\NOOOO.tga:32:32",
    ["yippee"] = "Interface\\AddOns\\TwitchEmotes_Baddies\\emotes\\yippee.tga:32:32",
    ["clappi"] = "Interface\\AddOns\\TwitchEmotes_Baddies\\emotes\\clappi.tga:32:32",
    ["Shrug"] = "Interface\\AddOns\\TwitchEmotes_Baddies\\emotes\\Shrug.tga:32:32",
    ["splort"] = "Interface\\AddOns\\TwitchEmotes_Baddies\\emotes\\splort.tga:32:32",
    ["ReallyMad"] = "Interface\\AddOns\\TwitchEmotes_Baddies\\emotes\\ReallyMad.tga:32:32",
    ["DOESHEKNOW"] = "Interface\\AddOns\\TwitchEmotes_Baddies\\emotes\\DOESHEKNOW.tga:32:32",
    ["CAUGHT"] = "Interface\\AddOns\\TwitchEmotes_Baddies\\emotes\\CAUGHT.tga:16:61",
    ["DEAL"] = "Interface\\AddOns\\TwitchEmotes_Baddies\\emotes\\DEAL.tga:16:96",
    ["doid"] = "Interface\\AddOns\\TwitchEmotes_Baddies\\emotes\\doid.tga:32:32",
    ["SadCatClown"] = "Interface\\AddOns\\TwitchEmotes_Baddies\\emotes\\SadCatClown.tga:32:32",
    ["FRICK"] = "Interface\\AddOns\\TwitchEmotes_Baddies\\emotes\\FRICK.tga:32:32",
    ["CEASE"] = "Interface\\AddOns\\TwitchEmotes_Baddies\\emotes\\CEASE.tga:32:32",
    ["sputWide"] = "Interface\\AddOns\\TwitchEmotes_Baddies\\emotes\\sputWide.tga:22:84",
    ["lookDown"] = "Interface\\AddOns\\TwitchEmotes_Baddies\\emotes\\lookDown.tga:32:32",
    ["lookUp"] = "Interface\\AddOns\\TwitchEmotes_Baddies\\emotes\\lookUp.tga:32:32",
    ["CRIKEN"] = "Interface\\AddOns\\TwitchEmotes_Baddies\\emotes\\CRIKEN.tga:32:27",
    ["SoyR"] = "Interface\\AddOns\\TwitchEmotes_Baddies\\emotes\\SoyR.tga:32:32",
    ["WHOLETHIMCOOK"] = "Interface\\AddOns\\TwitchEmotes_Baddies\\emotes\\WHOLETHIMCOOK.tga:32:32",
    ["THESTAFF"] = "Interface\\AddOns\\TwitchEmotes_Baddies\\emotes\\THESTAFF.tga:32:32",
    ["devious"] = "Interface\\AddOns\\TwitchEmotes_Baddies\\emotes\\devious.tga:32:32",
    ["RightThere"] = "Interface\\AddOns\\TwitchEmotes_Baddies\\emotes\\RightThere.tga:32:32",
    ["LetMeIn"] = "Interface\\AddOns\\TwitchEmotes_Baddies\\emotes\\LetMeIn.tga:32:32",
    ["CatAHomie"] = "Interface\\AddOns\\TwitchEmotes_Baddies\\emotes\\CatAHomie.tga:32:32",
    ["LockedIn"] = "Interface\\AddOns\\TwitchEmotes_Baddies\\emotes\\LockedIn.tga:32:32",
    ["AAAA"] = "Interface\\AddOns\\TwitchEmotes_Baddies\\emotes\\AAAA.tga:32:32",
    ["petbabey"] = "Interface\\AddOns\\TwitchEmotes_Baddies\\emotes\\petbabey.tga:32:32",
    ["babey"] = "Interface\\AddOns\\TwitchEmotes_Baddies\\emotes\\babey.tga:32:32",
    [""] = "Interface\\AddOns\\TwitchEmotes_Baddies\\emotes\\.tga:32:32",
    [""] = "Interface\\AddOns\\TwitchEmotes_Baddies\\emotes\\.tga:32:32",

}

-- Register animation metadata for animated Moosebrother emotes.
-- Keep this in sync with the spritesheets generated under /emotes.
-- glue.tga was generated as a vertical strip of 64 frames, each 32x32, total image height 2048, 15 fps
    TwitchEmotesBaddies_AddAnimation("Interface\\AddOns\\TwitchEmotes_Baddies\\emotes\\sputSussy.tga", 6, 112, 112, 112, 672, 10)
    TwitchEmotesBaddies_AddAnimation("Interface\\AddOns\\TwitchEmotes_Baddies\\emotes\\OhSnap.tga", 29, 56, 56, 56, 1624, 12.5)
    TwitchEmotesBaddies_AddAnimation("Interface\\AddOns\\TwitchEmotes_Baddies\\emotes\\mhm.tga", 9, 74, 64, 74, 576, 5)
    TwitchEmotesBaddies_AddAnimation("Interface\\AddOns\\TwitchEmotes_Baddies\\emotes\\GLORPSHIT.tga", 75, 92, 64, 92, 4800,33.33)
    TwitchEmotesBaddies_AddAnimation("Interface\\AddOns\\TwitchEmotes_Baddies\\emotes\\Shoo.tga", 45, 74, 64, 74, 2880, 16)
    TwitchEmotesBaddies_AddAnimation("Interface\\AddOns\\TwitchEmotes_Baddies\\emotes\\NOOOO.tga", 6, 102, 96, 102, 576, 33)
    TwitchEmotesBaddies_AddAnimation("Interface\\AddOns\\TwitchEmotes_Baddies\\emotes\\yippee.tga", 35, 96, 96, 96, 3360, 20)
    TwitchEmotesBaddies_AddAnimation("Interface\\AddOns\\TwitchEmotes_Baddies\\emotes\\clappi.tga", 29, 168, 96, 168, 2784, 33)
    TwitchEmotesBaddies_AddAnimation("Interface\\AddOns\\TwitchEmotes_Baddies\\emotes\\THESTAFF.tga", 32, 96, 96, 96, 3072, 8)
    TwitchEmotesBaddies_AddAnimation("Interface\\AddOns\\TwitchEmotes_Baddies\\emotes\\devious.tga", 21, 96, 96, 96, 2016, 25)
    TwitchEmotesBaddies_AddAnimation("Interface\\AddOns\\TwitchEmotes_Baddies\\emotes\\RightThere.tga", 56, 111, 96, 111, 5376, 25)
    TwitchEmotesBaddies_AddAnimation("Interface\\AddOns\\TwitchEmotes_Baddies\\emotes\\LetMeIn.tga", 46, 96, 96, 96, 4416, 20)
    TwitchEmotesBaddies_AddAnimation("Interface\\AddOns\\TwitchEmotes_Baddies\\emotes\\CatAHomie.tga", 20, 105, 96, 105, 1920, 10)
    TwitchEmotesBaddies_AddAnimation("Interface\\AddOns\\TwitchEmotes_Baddies\\emotes\\LockedIn.tga", 18, 105, 96, 105, 1728, 10)
    TwitchEmotesBaddies_AddAnimation("Interface\\AddOns\\TwitchEmotes_Baddies\\emotes\\AAAA.tga", 7, 96, 96, 96, 672, 30)
    TwitchEmotesBaddies_AddAnimation("Interface\\AddOns\\TwitchEmotes_Baddies\\emotes\\petbabey.tga", 5, 112, 112, 112, 560, 14)
    TwitchEmotesBaddies_AddAnimation("Interface\\AddOns\\TwitchEmotes_Baddies\\emotes\\.tga", 0, 0, 0, 0, 0, 0)
